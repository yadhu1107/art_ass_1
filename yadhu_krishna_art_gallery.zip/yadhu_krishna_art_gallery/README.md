# Artora — Art Gallery Website
**Prepared for:** Yadhu Krishna

A responsive front-end art gallery project built with HTML, CSS and JavaScript. No installation or build tools are required.

## Pages included
1. Login page
2. Sign-up page
3. Gallery home page
4. Artworks listing page with images, artist names and links
5. Six individual artwork pages (Mona Lisa, The Starry Night, The Kiss, Girl with a Pearl Earring, Sunflowers, and Water Lilies). Each has an image, artist, creation year, short description, medium, and similar artworks.

## How to run (Windows)
1. Download and extract `yadhu_krishna_art_gallery.zip`.
2. Open the extracted `yadhu_krishna_art_gallery` folder.
3. Double-click `index.html` to open it in Chrome or Edge.
4. Click **Gallery** or **Explore gallery** to see the artworks.
5. Click any artwork card to open its individual page.
6. Use **Log in** → **Create an account** to test sign-up and login.

### Recommended: run in VS Code
1. Open VS Code.
2. Choose **File → Open Folder** and select `yadhu_krishna_art_gallery`.
3. If you have the **Live Server** extension, right-click `index.html` and choose **Open with Live Server**.
4. The site opens in your browser. Save changes in VS Code and refresh if needed.

## Important notes
- An internet connection is needed for the remote artwork photos and Google Fonts.
- Login is a front-end demonstration only. Demo account data is stored in your browser's localStorage; this is **not secure authentication** and should not be used for real passwords.
- The website uses hash-based navigation, so no server is required.
